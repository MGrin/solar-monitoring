const io = require('./src/client.io')

const env = process.env
io(env)

